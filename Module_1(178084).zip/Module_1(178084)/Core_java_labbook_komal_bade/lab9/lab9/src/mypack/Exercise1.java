package mypack;

import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Exercise1 {
	List getValues(HashMap<String,Double> hm)
	{
		List<Map.Entry<String,Double>>l=new LinkedList<Map.Entry<String,Double>>(hm.entrySet());
		Collections.sort(l,new Comparator<Map.Entry<String,Double>>()
		{
			public int compare(Map.Entry<String, Double> o1,Map.Entry<String, Double> o2)
			{
				return(o1.getValue()).compareTo(o2.getValue());
			}
		});
		return l;
	}
	public static void main(String args[])
	{
		HashMap<String,Double>tm=new HashMap<String,Double>();
		Exercise1 h=new Exercise1();
		tm.put("komal",new Double(20000));
		tm.put("onkar",new Double(31000));
		tm.put("prakash",new Double(410000));
		List<Map<String,Double>>m=(List<Map<String,Double>>)h.getValues(tm);
		System.out.println(m);
		
	}

}
