package mypack;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise2 {

	
		Scanner sc=new Scanner(System.in);
		int temp,count;
		HashMap<Character,Integer>hm=new HashMap<Character,Integer>();
		Map countCharacter(char ch[])
		{
			HashMap<Character,Integer>hm=new HashMap<Character,Integer>();
			for(char c:ch)
			{
				if(hm.containsKey(c))
				{
					hm.put(c, hm.get(c)+1);
				}
				else
				{
					hm.put(c, 1);
				}
			}
			return hm;
		}
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Exercise2 e=new Exercise2();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter character array:");
			String s=sc.nextLine();
			char ch[]=s.toCharArray();
			System.out.println(e.countCharacter(ch));

	}

}
