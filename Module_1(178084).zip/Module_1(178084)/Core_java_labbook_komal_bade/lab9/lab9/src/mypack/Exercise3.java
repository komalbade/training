package mypack;

import java.util.HashMap;
import java.util.Map;

public class Exercise3 {
	
	Map getSquares(int b[])
	{
		HashMap<Integer,Integer>h=new HashMap<Integer,Integer>();
		for(int i=0;i<b.length;i++)
		{
			h.put(b[i], b[i]*b[i]);
		}
		return h;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Exercise3 e=new Exercise3();
		int a[]= {1,2,3,4,5,6};
		Map<Integer,Integer>hm=(Map<Integer,Integer>)e.getSquares(a);
		System.out.println(hm);
	}

}
