package newpackage;
import java.util.*;
public class StringTokenizerExample1 {
	
	public static void main(String[] args) {
	
		int sum=0,s1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter line of integer...");
		String sr=sc.nextLine();
		StringTokenizer st=new StringTokenizer(sr);
	    //StringTokenizer st=new StringTokenizer("12 45");
		while(st.hasMoreTokens())
		{
			String s=st.nextToken();
			System.out.println(s);
			s1=Integer.parseInt(s);
			sum=sum+s1;
		}
		System.out.println("sum of integer are:  "+sum);
		

	}

}
