package newpackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Exercise4 
{

	public static void main(String[] args) throws IOException
    {
		int countchar=0;
		int i;
		try
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a file location: ");
		String file=sc.next();
		FileInputStream fin=new FileInputStream(file);
		while((i=fin.read())!=-1)
		{
			countchar++;
		}
		File f=new File(file);
		if(f.isFile())
		{
			System.out.println("file exist...");
			if(f.canRead())
			{
				System.out.println("file is readable");
			}
			else
			{
				System.out.println("file is writable");
			}
		}
		else
		{
			System.out.println("file doesn't exist");
		}
		System.out.println("Type of the file is:  "+f.getPath());
		System.out.println("length of file(in byte):  "+countchar);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}

}
