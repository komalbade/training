package newpackage;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Exercise7 
{
	Scanner sc=new Scanner(System.in);
	
		boolean validate()
		{
			System.out.println("Enter username:");
			String userName=sc.next();
			if(Pattern.matches("\\D{4,}_job", userName))
			{
				return true;
			}
			else
			{
			    return false;
			}
		}
		public static void main(String args[])
		{
			Exercise7 e=new Exercise7();
			System.out.println("validation is passed: "+e.validate());
		}

	}

