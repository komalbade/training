package newpackage;

import java.util.Scanner;

public class Exercise5 
{
	 Scanner sc=new Scanner(System.in);
	public boolean checkString()
	{
		int res=0;
	
	  System.out.println("Enter a string");
	  String s=sc.next();
	  char ch[]=s.toCharArray();
	  for(int i=0;i<ch.length;i++)
	  {
		  for(int j=i+1;j<ch.length;j++) 
		  {
			  if((ch[i]>=65 && ch[i]<=90))
			  {
				  res=0;
				  if(ch[i]<ch[j])
				  {
					  res=1;
					  //return false 
				  }
			  
			  }
		  }
	
	  }
	  if(res==1)
		  	return true;
	  else 
		    return false;
	  
	}
	public static void main(String[] args) 
	{
	 Exercise5 e=new Exercise5();
	
	System.out.println("check weather string is positive or not: "+e.checkString());

	}

}
