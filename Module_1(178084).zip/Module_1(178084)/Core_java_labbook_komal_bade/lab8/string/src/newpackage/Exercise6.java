package newpackage;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Exercise6  {
 
 public void compareDate()
 {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter date(YYYY-MM-DD:  ");
	 SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd");
	 try
	 {
	 String s=sc.next();
	 Date date=new Date();		
		 int x=date.getDate();
		 int x1=date.getMonth();
		 int x2=date.getYear();
		 System.out.println(date);
		 Date date1=f.parse(s);
		 int y=date1.getDate();
		 int y1=date1.getMonth();
		 int y2=date1.getYear();
		 System.out.println(date1);
		 System.out.println(x);
		 System.out.println(x1);
		 System.out.println(x2);
		
		 System.out.println("Duration in days are "+(y-x));
		 System.out.println("Duration in months are "+(y1-x1));
		 System.out.println("Duration in year are "+(y2-x2));
	 }
	 catch(ParseException e)
	 {
		 
	 }
	
 }
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Exercise6 e=new Exercise6();
		e.compareDate();

	}

}
