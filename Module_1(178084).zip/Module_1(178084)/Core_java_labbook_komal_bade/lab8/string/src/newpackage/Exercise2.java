package newpackage;
import java.io.FileInputStream;
import java.io.IOException;
public class Exercise2 
{
  public static void main(String[] args)throws IOException
  {
		
	  try
	  {
		  //FileInputStream fin=new FileInputStream("D:\\komal_practice\\Cube.java");
		  FileInputStream fin=new FileInputStream("D:\\test.text");
		  int i=0;
		  int count=2;
		  System.out.print("1 ");
		  while((i=fin.read())!=-1)
		  {
			System.out.print((char)i);
			if((char)i=='\n')
			{
				//count++;
				System.out.print(count+" ");
				count++;
			}
			
		}
		fin.close();
     }
    catch(Exception e)
    {
	   System.out.println(e);
    }

  }

}
