package newpackage;

import java.io.FileReader;
import java.io.IOException;

public class Exercise3 {

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		int cntchar=0;
		int cntword=1;
		int cntline=1,i=0;
		FileReader f1=new FileReader("D:\\test.text");
		try
		{
		while((i=f1.read())!=-1)
		{
			cntchar++;
			char ch=(char)i;
			if(ch==' '||ch=='\n')
			{
				cntword++;
			}
			if(ch=='\n')
			{
				cntline++;
			}
		}
		System.out.println("Total number of character in file are: " +cntchar);
		System.out.println("Total number of words in file are: " +cntword);
		System.out.println("Total number of lines in file are: " +cntline);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
