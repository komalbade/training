package assign;

public class CountCharacter {

	int temp;

	void countcharacter() {

		// String s="happy";
		// char ch[]= s.toCharArray();
		char ch[] = { 'k', 'o', 'm', 'm', 'l' };
		for (char cha = 'a'; cha <= 'z'; cha++) {
			int count = 0;
			for (int i = 0; i < ch.length; i++) {
				if (cha == ch[i]) {
					count++;
				}
			}
			if (count != 0) {
				System.out.println(cha + " repeted " + count);
			}
		}
	}

	public static void main(String[] args) {
		CountCharacter c = new CountCharacter();
		c.countcharacter();
		// TODO Auto-generated method stub

	}

}
