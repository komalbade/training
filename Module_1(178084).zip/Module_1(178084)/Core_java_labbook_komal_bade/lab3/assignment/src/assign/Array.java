package assign;

public class Array 
{
  public int getSecondSmallest(int a[],int length)
  {

	 int temp;
	 for(int i=0;i<length;i++)
	 {
		 for(int j=i+1;j<length;j++)
		 {
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		 }
	 }
	 
	 return a[1];
  }
   public static void main(String [] args)
   {
	 int arr[]= {45,62,100,5,30};
	 Array r=new Array();
	 System.out.println("Second smallest number in array "+ r.getSecondSmallest(arr,5));
	   
   }
  
}
