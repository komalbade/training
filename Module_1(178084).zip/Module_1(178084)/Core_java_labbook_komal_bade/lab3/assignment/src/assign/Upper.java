package assign;

import java.util.Arrays;

public class Upper 
{    
	
 public void upperCase()
 {
	 String upper ="";
	 String s="bade";
	 char ch[]=s.toCharArray();
	 Arrays.sort(ch);
	 String str = new String(ch);
	 if(str.length()%2==0)
	 {
		for(int i=0;i<str.length()/2;i++)
		{
			upper=upper+Character.toUpperCase(str.charAt(i));
			
		}
		
		for(int i=str.length()/2;i<str.length();i++) 
		{
		    upper=upper+Character.toLowerCase(str.charAt(i));
		}
		
		System.out.println(upper);
	 }
	 else
	 {
		 for(int i=0;i<str.length()/2+1;i++)
		 {
			 upper=upper+Character.toUpperCase(str.charAt(i)); 
		 }
		 for(int i=0;i<str.length()/2+1;i++)
		 {
			 upper=upper+Character.toLowerCase(str.charAt(i));
		 }
		 System.out.println(upper);
	 }
	 
}
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
       Upper u=new Upper();
       u.upperCase();
	}

}
