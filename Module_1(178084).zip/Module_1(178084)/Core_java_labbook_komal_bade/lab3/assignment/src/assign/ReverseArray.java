package assign;

import java.util.Arrays;


public class ReverseArray {
    public static int [] Rev(int[] a){
    	int arr[]=new int[a.length];
    	System.out.println("After reversing... ");
    	for(int i=a.length-1,j=0;i>=0;i--,j++) {
    		arr[j]=a[i];
    		System.out.println(arr[j]);
    	}
    	Arrays.sort(arr);
        return arr;
    }
	public static void main(String[] args) {
		int arr[]= {40,100,26,78,49};
		int arr1[]=Rev(arr);
		
		System.out.println("After sorting array of reverse... ");
		for(int i=0;i<arr1.length;i++) {
			System.out.println( arr1[i]);
			//System.out.println(arr);
		}
		
		// TODO Auto-generated method stub

	}

}
