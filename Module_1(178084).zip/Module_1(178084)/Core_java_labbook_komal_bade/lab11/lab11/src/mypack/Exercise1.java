package mypack;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class CopyDataThread implements Runnable
{
	private String message;
	public CopyDataThread(String message)
	{
		this.message=message;
	}

public void run()
{
	try {
		FileInputStream fin=new FileInputStream("c:\\Users\\kobade\\JavaProgram\\Runtime2.java");
		FileOutputStream fout=new FileOutputStream("c:\\Users\\kobade\\JavaProgram\\Runtime2.java");
	    int i=0;
		int count=0;
		while((i=fin.read())!=-1)
		{
			fout.write((byte)i);
			count++;
			if(count%10==0)
			{
				try {
					Thread.sleep(5000);
					System.out.println(Thread.currentThread()+"10 characters are copied");
				}catch(Exception e) {
					
				}
			}
		}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
public static void main(String args[])
{
	ExecutorService executor=Executors.newFixedThreadPool(5);
	Runnable worker=new CopyDataThread("");
	executor.shutdown();
	while(!executor.isTerminated()) { }
	System.out.println("Finished all threads");
}	
}