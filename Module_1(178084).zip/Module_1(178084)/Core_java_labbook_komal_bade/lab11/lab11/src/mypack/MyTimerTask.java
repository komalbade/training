package mypack;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyTimerTask extends TimerTask{

	
	@Override
	public void run() {
		System.out.println("Timer task started at: "+new Date());
		
	}
	public static void main(String[] args) {
		ExecutorService executor=Executors.newFixedThreadPool(5);
		Runnable worker=new MyTimerTask();
		TimerTask timerTask=new MyTimerTask(); 
		Timer timer=new Timer(true);
		timer.scheduleAtFixedRate(timerTask,0,10*1000);
		System.out.println("Timer task started: ");
		try {
			Thread.sleep(120000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		timer.cancel();
		System.out.println("TimerTask cancelled: ");
		try {
			Thread.sleep(30000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		executor.shutdown();
		while(!executor.isTerminated()) { }
		System.out.println("Finished all threads");
	}

}
