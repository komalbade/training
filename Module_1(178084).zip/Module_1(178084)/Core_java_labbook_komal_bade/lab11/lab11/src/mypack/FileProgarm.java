package mypack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileProgarm extends Thread {
	FileInputStream fin;
	FileOutputStream fout;
	public void FileProgram() throws FileNotFoundException
	{
		FileInputStream fin=new FileInputStream("c:\\Users\\kobade\\JavaProgram\\Runtime2.java");
		FileOutputStream fout=new FileOutputStream("c:\\Users\\kobade\\JavaProgram\\Runtime3.java");
	}
	public void run()
	{
		try {
			int i=0;
			int count=0;
			while((i=fin.read())!=-1)
			{
				fout.write((byte)i);
				count++;
				if(count%10==0)
				{
					try
					{
						Thread.sleep(5000);
						System.out.println("10 characters are copied: ");
					}catch(Exception e) { }
				}
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
public static void main(String args[])
{
	ExecutorService executor=Executors.newFixedThreadPool(5);
	Runnable worker=new CopyDataThread("");
	executor.shutdown();
	while(!executor.isTerminated()) { }
	System.out.println("Finished all threads");
}
}
