package com.cg.mypack;

public abstract class WrittenItem extends Item 
{
 private String author;

public WrittenItem()
{
	System.out.println("I am in WrittenItem...");
}
 public WrittenItem(String author)
{
	this.author = author;
}

public String getAuthor() 
{
	return author;
}

/*public void setAuthor(String author) 
{
	this.author = author;
}*/
public WrittenItem(int id_num,String title,int no_of_copies ) 
{
	super(id_num,title,no_of_copies);
}

/*@Override
public String toString() 
{
	return "WrittenItem [author=" + author + ", getId()=" + getId() + ", getTitle()=" + getTitle() + ", getNc()="
			+ getNc() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
			+ "]";
}*/
}