package com.cg.mypack;

public class JournalPaper extends WrittenItem 
{
 private int year;
 
public JournalPaper()
{
  //year=2019;	
}

public JournalPaper(int year)
{
	this.year=year;
}
public int getYear() 
{
	return year;
}

/*public void setYear(int year) 
{
	this.year = year;
}*/
}
