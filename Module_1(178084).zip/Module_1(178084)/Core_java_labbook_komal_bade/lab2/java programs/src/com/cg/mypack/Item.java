package com.cg.mypack;

public abstract class Item 
{
	private int id_num;
	private String title;
	private int no_of_copies;
	
	public Item()
	{
		//System.out.println("I am in Item constuctor...");
	}
	public Item(int id_num,String title,int no_of_copies)
	{
		this.id_num=id_num;
		this.title=title;
		this.no_of_copies=no_of_copies;
	}
	
	public int getId() 
	{
		return id_num;
	}
	/*public void setId(int id) {
		this.id = id;
	}*/
	public String getTitle() 
	{
		return title;
	}
	/*public void setTitle(String title) {
		this.title = title;
	}*/
	public int getNc() 
	{
		return no_of_copies;
	}
	/*public void setNc(int nc) {
		this.nc = nc;
	}*/
	
}
