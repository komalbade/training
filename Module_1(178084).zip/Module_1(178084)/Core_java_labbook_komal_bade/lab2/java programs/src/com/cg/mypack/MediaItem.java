package com.cg.mypack;

public abstract class MediaItem extends Item 
{
	private int runtime;
	
	public MediaItem()
	{
		
	}
	
   public MediaItem(int runtime)
   {
	this.runtime=runtime;   
   }
   public int getruntime()
   {
	   return runtime;
   }
   /*public MediaItem(int id_num,String title,int no_of_copies)
   {
	   super(id_num,title,no_of_copies);
   }*/
}
