package com.cg.mypack;

public class Video extends MediaItem 
{
	private String director;
	private String genre;
	private int year;
	public Video(int runtime)
	{
		super(runtime);
	}
	
	public void setv(String director,String genre,int year)
	
	{
		this.director=director;
		this.genre=genre;
		this.year=year;
	}
	public String getDirector()
	{
		return director;
	}
	public String getGenre()
	{
		return genre;
	}
	public int getYear()
	{
		return year;
	}
	
}
