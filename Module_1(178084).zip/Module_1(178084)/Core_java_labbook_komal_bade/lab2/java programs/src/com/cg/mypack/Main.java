package com.cg.mypack;

public class Main 
{
	public static void main(String args[])
	{
		Book b1=new Book("Komal");
		Book b2=new Book(5,"Success",50);
		JournalPaper j=new JournalPaper(2019);
		
		
		System.out.println("Author name is "+ b1.getAuthor());
		System.out.println("Identification number is "+ b2.getId());
		System.out.println("title name is " +b2.getTitle());
		System.out.println("Number of copies "+ b2.getNc());
		System.out.println("The year is " + j.getYear());
		
		
		Video v=new Video(10);
		v.setv("Sanjay leela Bansali", " Historical", 2018);
		System.out.println("The director name is " +v.getDirector());
		System.out.println("The genre name is " +v.getGenre());
		System.out.println("The year is " + v.getYear());
		System.out.println("the runtime "+ v.getruntime());
		
		CD c= new CD(20);
		c.setc("Dipika","Action");
		System.out.println("The name of artist is "+ c.getArtist());
		System.out.println("The name of Genre is "+c.getGenre());
		System.out.println("the runtime is "+c.getruntime() );
	}
}


