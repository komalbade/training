package com.cg.mypack;

public class CD extends MediaItem 
{
	private String artist;
	private String genre;

	public CD(int runtime)
	{
		super(runtime);
	}
public void setc(String artist,String genre)
{
	this.artist=artist;
	this.genre=genre;
}

public String getArtist()
{
	return artist;
}

public String getGenre()
{
	return genre;
}
}
