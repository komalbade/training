package com.cg.mypack;

public class Book extends WrittenItem 
{
 public Book(String author)
 {
	 super(author);
 }
 public Book(int num,String title,int no_of_copies)
 {
  super(num,title,no_of_copies);
 }
	
}
