package mypack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileProgram {

	public FileProgram() throws IOException {
		BufferedReader br = new BufferedReader(
				new FileReader("D:\\MyData\\MySpringProjects\\Module1\\src\\lab10\\source.txt"));

		BufferedWriter bw = new BufferedWriter(
				new FileWriter("D:\\MyData\\MySpringProjects\\Module1\\src\\lab10\\target.txt"));
		CopyDataThread c = new CopyDataThread(br, bw);
	}

}
