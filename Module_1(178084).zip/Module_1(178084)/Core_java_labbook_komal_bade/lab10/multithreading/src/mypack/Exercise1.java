package mypack;

import java.io.IOException;

public class Exercise1 {

	public static void main(String args[])throws IOException{
		
		FileProgram f=new FileProgram();
	}

	}


