public class Power
{
public boolean checkNumber(int num)
{
 if(num!=0 && (num & (num-1))==0)
{

  return true;
}
else
{

 return false;
}

}


public static void main(String args[])
{
Power obj1=new Power();
int num=11;
if(obj1.checkNumber(num)==true)
{
System.out.print("number"+num+"is power of 2");

}
else
{
System.out.print("number"+num+"is not power of 2");
}

}
}