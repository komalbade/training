public class Square
{
public void calculateDifference()
{

int n=5,i,sum=0,sum1=0,diff;
for(i=1;i<=n;i++)
{
 sum=sum+(i*i);
 sum1=sum1+i;
}
int square2= sum1*sum1;
diff=sum-square2;
System.out.println("diff="+diff);

}
public static void main(String args[])
{
 Square obj1=new Square();
 obj1.calculateDifference();

}
}