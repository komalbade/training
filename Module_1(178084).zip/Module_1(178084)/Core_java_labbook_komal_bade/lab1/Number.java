public class Number
{
public void calculateSum()
{
 int n=5,i,sum=0;
for(i=1;i<=n;i++)
{

if(i%3==0 ||i%5==0)
{
sum=sum+i;
}
}
System.out.print("sum=  "+ sum);
}

public static void main(String args[])
{
Number obj=new Number();
obj.calculateSum();
}
}