public class Increase
{ 

public static boolean CheckNumber(int num)
{

 boolean flag=true;                                                                                            
 int rem=num%10;
 num=num/10;
 

while(num>0)
{
 if(rem<=num%10)
{
flag=false;
}

rem=num%10;
num=num/10;
}
return flag;
}

public static void main(String args[])
{
 int num=941;
 int temp=num;
if(CheckNumber(num)==true)
{
System.out.print("Number "+temp+ "is increasing number");

}

else
{
System.out.print("Number "+temp+ "is not increasing number");
}


}
}