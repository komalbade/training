package com.cg.mypack;

public class Cube 
{
  int num=54321457,sum=0,rem;
  public void sum()
  {   
	  while(num>0)
	  {
	    rem=num%10;
	    sum=sum+(rem*rem*rem);
	    num=num/10;
	  
	  }
	  System.out.println("Sum of cubes of digits= "+ sum);
  }

public static void main(String []args)
    {
    	Cube c=new Cube();
    	c.sum();
    }
}


