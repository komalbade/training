package com.cg.eis.exception;

public class EmployeeException extends Exception {
   EmployeeException(String s){
	   super(s);
   }
}
