package com.cg.pack;

public class AgeOfPersonException extends Exception 
{
	AgeOfPersonException(String s)
	{
		super(s);
	}
}
