package com.cg.pack;
import java.util.Scanner;
public class SwitchCase 
{
	Scanner sc=new Scanner(System.in);
public void trafficlightcontrol()
{   
	System.out.println("Enter a choice:1.red(stop)"+ "2.yellow(ready)"+ "3.green(go)");
    String choice=sc.next();
    switch(choice)
    {
    case "red":
    	System.out.println("Please Stop");
    	break;
    case "yellow":
    	System.out.println("Please Ready");
    	break;
    case "green":
    	System.out.println("Please Go");
    	break;
    default:
    	System.out.println("invilid choice...  ");
    	System.out.println("Please enter right choice:red ");
    }
}
public static void main(String args[])
{
	SwitchCase s=new SwitchCase();
	s.trafficlightcontrol();
}
}
