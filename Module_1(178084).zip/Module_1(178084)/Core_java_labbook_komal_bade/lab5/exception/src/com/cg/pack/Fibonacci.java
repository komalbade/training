package com.cg.pack;
import java.util.Scanner;
public class Fibonacci 
{
	Scanner sc=new Scanner(System.in);
  int t1=1;
  int t2=1;
  int t3;
  int value;
  //Fibonacci sequence without recursion
  
  void displayvalue()
  {
	  
	  System.out.println("Enter nth value");
	  int value=sc.nextInt();
	  System.out.println("Fibonacci series without Recursion: ");
	  for(int i=0;i<value;i++)
	  {
		  System.out.println(t1+"");
		  t3=t1;
		  t1=t2;
		  t2=t2+t3;
	  }
	  System.out.println();
}
  //Fibonacci sequence with recursion
  
  int fibonacciRecursion(int term)
  {
	  if(term==0)
		  return 1;
	  if(term==1)
		  return 1;
	  else
		  return fibonacciRecursion(term-1)+fibonacciRecursion(term-2);
  }
  public static void main(String args[])
  {
	  Fibonacci f=new Fibonacci();
	  f.displayvalue();
	  System.out.println("Fibonacci series with Recursion:");
	  for(int n=0;n<f.value;n++)
		  System.out.println(f.fibonacciRecursion(n)+" ");
  }
}
