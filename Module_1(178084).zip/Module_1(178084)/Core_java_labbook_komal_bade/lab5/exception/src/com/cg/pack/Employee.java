package com.cg.pack;
import java.util.Scanner;
class NoValidateException extends Exception
{
	 String name;
	NoValidateException(String name)
	{
		this.name=name;
	}

	public String tostring()
	{
		return "exception";
	}

}
public class Employee 
{
	Scanner sc=new Scanner(System.in);
	String firstName=" ";
	String lastname=" ";
	
	void validateForm()
	{ 
		System.out.println("Enter first name: ");
		firstName=sc.nextLine();
		System.out.println("Enter last name: ");
        lastname=sc.nextLine();
        String name=firstName+lastname;
       try
       {
        if(firstName.equals("") && lastname.equals(""))
        {
        	throw new NoValidateException(name);
        }
	
        else
        {
        	System.out.println("countinue...");
        }
       }
       catch(NoValidateException e)
       {
    	   System.out.println("enter fn and ln");
       }
    }

	public static void main(String[] args)
	{
		Employee r=new Employee();
		r.validateForm();

	}

}
