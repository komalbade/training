package com.cg.pack;
import java.util.Scanner;

public class PrimeNumber 
{ 
	Scanner scan=new Scanner(System.in);
	public void getnumber()
	{
		System.out.println("Enter any integer: ");
		int integer=scan.nextInt();
		for(int i=2;i<=integer;i++)
		{
			int count=0;
			int num=i;
			for(int j=1;j<=num;j++)
			{
				if(num%j==0)
				{
					count++; 
				}
				
			}
				
	if(count==2)
	{
		System.out.println(num+ "  is a prime number");
		//System.out.println(num);
		
	}
		
    else
    {
		System.out.println(num+ "  is not a prime number");
    }
	}
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		PrimeNumber p=new PrimeNumber();
		p.getnumber();

	}

}
