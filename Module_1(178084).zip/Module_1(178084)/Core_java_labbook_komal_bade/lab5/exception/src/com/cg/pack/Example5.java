package com.cg.pack;

public class Example5
{
 public static void validate(int age)throws AgeOfPersonException
 {
	 if(age<15)
		 throw new AgeOfPersonException("Not Valid");
	 else
		 System.out.println(" valid");
 }
  public static void main(String[] args) 
  {
	  // TODO Auto-generated method stub
	  try
	  {
		  validate(19);
	  }
	  catch(Exception e)
	  {
		  System.out.println("Exception occured  "+e);
		  System.out.println("Rest of code...");
	  }

  }

}
