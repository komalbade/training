package pack;

import java.util.Scanner;
import java.util.regex.Pattern;

interface LambadaExpressionExample3
{
	public boolean validate();
}

public class LambadaEx3 {
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter first name:  ");
	String fname=sc.next();
	System.out.println("Enter passward:  ");
	String pwd=sc.next();
	LambadaExpressionExample3 l=()->{
		if(Pattern.matches("[\\w]*",fname))
		{
			if(Pattern.matches("[A-Z]{1}[a-zA-Z0-9@]{5}",pwd))
			{
				return true;
			}
		}return false;
	};
	System.out.println("check pasward or name is correct:  "+l.validate());
}

}
