package pack;

import java.util.Scanner;

interface sayable{
	String toString1();
}

public class LambadaEx4 {

	private static int eid;
	private static String ename;
	private static long esal;
	
	public static int getEid() {
		return eid;
	}
	public static void setEid(int eid) {
		LambadaEx4.eid = eid;
	}
	public static String getEname() {
		return ename;
	}
	public static void setEname(String ename) {
		LambadaEx4.ename = ename;
	}
	public static long getEsal() {
		return esal;
	}
	public static void setEsal(long esal) {
		LambadaEx4.esal = esal;
	}
	@Override
	public String toString() {
		return "LambadaEx4 [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Id name and salary: ");
		int id=sc.nextInt();
		String name1=sc.next();
		long sal=sc.nextLong();
		LambadaEx4 l=new LambadaEx4();
		l.setEid(id);
		l.setEname(name1);
		l.setEsal(sal);
		sayable s=l::toString;
		System.out.println(l.toString());
		
		}

}
