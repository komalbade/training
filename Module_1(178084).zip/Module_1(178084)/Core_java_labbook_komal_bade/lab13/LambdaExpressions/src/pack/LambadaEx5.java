package pack;

interface sayable1{
	int fact(int x);
}
public class LambadaEx5 {
	int res=1;
	int fact(int x)
	{
		for(int i=1;i<=x;i++)
		{
			res=res*i;
		}
		return res;
	}
	public static void main(String[] args) {
		
		 LambadaEx5 l=new LambadaEx5();
		 sayable1 s=l::fact;
		 System.out.println("Factorial of 5 is: "+s.fact(5));
	}

}
