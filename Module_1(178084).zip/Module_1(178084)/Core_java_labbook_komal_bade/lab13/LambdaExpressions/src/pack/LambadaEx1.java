package pack;

interface LambadaExpressionExample1
{
	public int add(int x,int y);
}


public class LambadaEx1 {

	static int res=1;
	public static void main(String args[])
	{
		LambadaExpressionExample1 l=(x,y)->{
			for(int i=1;i<=y;i++)
				res=res*x;
			return res;
		};
		System.out.println("result :  "+l.add(2, 3));
	}
}
