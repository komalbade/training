package pack;

import java.util.Scanner;

interface LambadaExpressionExample2
{
	public String getFormattedName();
}
public class LambadaEx2 {

	public static void main(String args[])
	{
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter a string:  ");
	 String name=sc.next();
	 StringBuilder sb=new StringBuilder();
	 LambadaExpressionExample2 l=()->{
		 for(char c: name.toCharArray()) {
			 sb.append(c).append(" ");
		 }
		 return sb.toString();
	 };
	 System.out.println(l.getFormattedName());
	}
}
