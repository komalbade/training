package com.capgemini.paywalt.pres;

import java.util.*;

import com.capgemini.paywalt.bean.Customer;
import com.capgemini.paywalt.exception.CustomerException;
import com.capgemini.paywalt.service.CustomerService;
import com.capgemini.paywalt.service.CustomerServiceImp;
import com.capgemini.paywalt.service.CustomerValidation;

public class MainUI extends CustomerException{

	public static void main(String[] args) throws CustomerException {

		String userName, password, accountNo = null, bankName;
		
		Scanner sc = new Scanner(System.in);
		
		CustomerService service = new CustomerServiceImp();
		CustomerValidation validator = new CustomerValidation();
		int options;
		
		
		do {
			Customer cust = new Customer();
			
			System.out.println("1.Create payment wallet Account.");
			System.out.println("2.Show Customer Details.");
			System.out.println("3.Show Balance..");
			System.out.println("4.Deposite your Balance.");
			System.out.println("5.Withdraw Balance.");
			System.out.println("6.Fund Transfer.");
			System.out.println("7.Print Transaction.");
			System.out.println("8.Exit.");
			System.out.println("Choose your Options... :");
			
			options = sc.nextInt();
			switch(options) {
				
			case 1 :
				try {
					System.out.println("Registration....\nPlease Enter your details...");
					System.out.println("Enter your Name:");
					String name = sc.next();
					if(validator.getValidateName(name) == false)
						throw new CustomerException("Customer Name start should be  Capital.(Name length should be 3-20 alphabet)");
					
					System.out.println("Enter your Address:");
					String address = sc.next();
					if(validator.getValidateAddress(address) == false)
						throw new CustomerException("You Enter Invalid Address.");
					
					System.out.println("Enter your Phone No:");
					String phoneNo = sc.next();
					if(validator.getValidatePhone(phoneNo) == false)
						throw new CustomerException("Enter your Valid Phone number.");
					
					/*System.out.println("Enter your User Name:");
					userName = sc.next();
					
					System.out.println("Enter your password:");
					password = sc.next();*/
					
					System.out.println("Enter your AccountNo:");
					accountNo = sc.next();
					if(validator.getValidateAccNo(accountNo)==false)
						throw new CustomerException("Enter Your Valid Account No.Account no must be 8 digit.");
					
					System.out.println("Enter your Bank Name:");
					bankName = sc.next();
					if(validator.getValidateBankName(bankName)==false)
						throw new CustomerException("Invalid bank Name.");
					
					cust.setName(name);
					cust.setAddress(address);
					cust.setPhoneNo(phoneNo);
					//cust.setUserName(userName);
					//cust.setPassword(password);
					cust.setAccountNo(Long.parseLong(accountNo));
					cust.setBankName(bankName);
					service.createAcc(cust);
				}catch(CustomerException e) {
					System.out.println(e);
				}
					
					
				break;
			/*	
			case 8:
				System.out.println("LogIn.....");
				
				System.out.println("Enter your User Name:");
				String uName = sc.next();
				
				System.out.println("Enter your password:");
				String pass = sc.next();
				
				if(userName.equals(uName) && password.equals(pass)) {
					
					System.out.println("You have sucessfully LogIn......\nNow Add Your Bank Account \n");
					
					System.out.println("Enter your Bank AccountNo:");
					accountNo = sc.next();
					System.out.println("Add Your Bank Name");
					bankName = sc.next();
					
					cust.setAccountNo(Long.parseLong(accountNo));
					cust.setBankName(bankName);
					
					System.out.println("Enter your User Name:");
					userName = sc.next();
					service.createAcc(cust);
				
//					Customer cust1=service.addAcc(cust);
//					System.out.println(cust1);
					
					
				}
				else {
					System.out.println("Enter your correct User Name & password \n otherwise 1st you have to SignIn.");
				}
				break;*/
				
				
			case 2 :
					try {
						ArrayList<Customer> list= service.showCustomerDetails();
						for(Customer c : list)
							System.out.println(c);
					}catch(CustomerException e) {
						System.out.println(e);
					}
				break;
			
				
			case 3 :
						try {
						System.out.println("Enter your Account No:");
						String accoNo = sc.next();
						if(accountNo.equals(accoNo)) {
							 cust = service.showBalance(Long.parseLong(accoNo));
							System.out.println("Total Balance= "+cust.getBalance());
						}
						else {
							System.out.println("Your AccountNo is Not Correct...");
						}
					}catch(CustomerException e) {
						System.out.println(e);
					}
						
				break;
				
				
			case 4 :
					try {
						
						System.out.println("Enter your AccountNo:");
						accountNo = sc.next();
						System.out.println("Enter your Balance:");
						String balance = sc.next();
						
						cust = service.deposite(Long.parseLong(accountNo),Double.parseDouble(balance));
						service.showBalance(cust.getAccountNo());
						System.out.println("Your Balance "+balance+" is credited.");
					}catch(CustomerException e) {
						System.out.println(e);
					}
				break;
				
				
			case 5 :
					try {
						System.out.println("Enter Your AccountNo:");
						accountNo = sc.next();
						System.out.println("Enter your withdraw balance:");
						String withBalance = sc.next();
						
						cust = service.withdraw(Long.parseLong(accountNo),Double.parseDouble(withBalance));
						service.showBalance(cust.getAccountNo());
						System.out.println("Your Balance "+withBalance+" is debited.");
						
					}catch(CustomerException e) {
						System.out.println(e);
					}
				break;
				
				
			case 6 :
				break;
				
				
			case 7 :
				break;	
			
			
			case 8 :
				break;	
			}
			
		}while(options != 8);
	}

}
