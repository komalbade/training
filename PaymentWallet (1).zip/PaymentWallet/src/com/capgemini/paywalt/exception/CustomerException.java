package com.capgemini.paywalt.exception;

public class CustomerException extends Exception{

	public CustomerException() {
		super();
		
	}

	public CustomerException(String s) {
		super(s);
		
	}

	
}
