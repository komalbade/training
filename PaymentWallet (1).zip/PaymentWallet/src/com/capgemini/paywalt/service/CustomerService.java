package com.capgemini.paywalt.service;

import java.util.ArrayList;

import com.capgemini.paywalt.bean.Customer;
import com.capgemini.paywalt.exception.CustomerException;

public interface CustomerService {

	public Customer createAcc(Customer cust) throws CustomerException;
	
	public Customer addAcc(Customer cust) throws CustomerException;
	
	public ArrayList<Customer> showCustomerDetails() throws CustomerException;
	
	public Customer showBalance(long accNo) throws CustomerException;
	
	public Customer deposite(long accNo, double balance) throws CustomerException;
	
	public Customer withdraw(long accNo, double balance) throws CustomerException;
	
	public Customer fundTransfer() throws CustomerException;
	
	public Customer printTransaction(long accNo) throws CustomerException;
}
