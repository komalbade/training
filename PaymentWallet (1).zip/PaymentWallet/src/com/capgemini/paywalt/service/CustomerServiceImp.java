package com.capgemini.paywalt.service;

import java.util.ArrayList;

import com.capgemini.paywalt.bean.Customer;
import com.capgemini.paywalt.dao.CustomerDAO;
import com.capgemini.paywalt.dao.CustomerDAOImp;
import com.capgemini.paywalt.exception.CustomerException;

public class CustomerServiceImp implements CustomerService{

	CustomerDAO dao;
	
	
	
	public CustomerServiceImp() {

		dao = new CustomerDAOImp();
	}

	@Override
	public Customer createAcc(Customer cust) throws CustomerException {

		cust = dao.createAcc(cust);
		
		return cust;
	}

	@Override
	public Customer addAcc(Customer cust) throws CustomerException {
		
		return null;
	}

	@Override
	public Customer showBalance(long accoNo) throws CustomerException {
		
		return dao.showBalance(accoNo);
	}

	@Override
	public Customer deposite(long accNo,double balance) throws CustomerException {
		
		return dao.deposite(accNo,balance);
	}

	@Override
	public Customer withdraw(long accNo,double balance) throws CustomerException {
		
		return dao.withdraw(accNo,balance);
	}

	@Override
	public Customer fundTransfer() throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer printTransaction(long accNo) throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Customer> showCustomerDetails() throws CustomerException {

		return dao.showCustomerDetails();
	}

}
