package com.capgemini.paywalt.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.paywalt.service.CustomerValidation;

public class CustomerTest {

	CustomerValidation validator = new CustomerValidation();
	@Test
	public void testMethod1() {
		String name = "Arjun";
		boolean actual = validator.getValidateName(name);
		boolean expected =true;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod2() {
		String address = "sdf";
		boolean actual = validator.getValidateAddress(address);
		boolean expected = false;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod3() {
		String phone="8972479969";
		boolean actual = validator.getValidatePhone(phone);
		boolean expected = true;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod4() {
		String accNo="12365498";
		boolean actual = validator.getValidateAccNo(accNo);
		boolean expected = true;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod5() {
		String bankName="bi";
		boolean actual = validator.getValidateBankName(bankName);
		boolean expected = false;
		assertEquals(expected, actual);
	}
}
