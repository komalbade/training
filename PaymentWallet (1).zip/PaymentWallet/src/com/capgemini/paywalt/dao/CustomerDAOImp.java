package com.capgemini.paywalt.dao;

import java.util.*;

import com.capgemini.paywalt.bean.Customer;
import com.capgemini.paywalt.exception.CustomerException;

public class CustomerDAOImp implements CustomerDAO{

	Map<Long,Customer> customer = new HashMap<>();
	
	@Override
	public Customer createAcc(Customer cust) throws CustomerException {
		customer.put((long) cust.getAccountNo(), cust);
		return cust;
	}

	@Override
	public Customer addAcc(Customer cust) throws CustomerException {
		
		
		return null;
	}

	@Override
	public Customer showBalance(long accNo) throws CustomerException {
		Customer cust=customer.get(accNo);
		double balance = cust.getBalance();
		return cust;
	}

	@Override
	public Customer deposite(long accNo,double balance) throws CustomerException {
		
		Customer cust=customer.get(accNo);
		//System.out.println(cust);
		double currentbalance=cust.getBalance();
		
		double totalbalance=currentbalance+balance;
		cust.setBalance(totalbalance);
		//System.out.println("Total Balance= "+totalbalance);
		
		return cust;
	}

	@Override
	public Customer withdraw(long accNo,double balance) throws CustomerException {
		Customer cust = customer.get(accNo);
		double curBalance = cust.getBalance();
		double totalBalance = curBalance - balance;
		cust.setBalance(totalBalance);
		return cust;
	}

	@Override
	public Customer fundTransfer() throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer printTransaction(long accNo) throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Customer> showCustomerDetails() throws CustomerException {
		Collection<Customer> c = customer.values();
		ArrayList<Customer> list = new ArrayList<>(c);
		return list;
	}

	@Override
	public Customer getUserName(String userName) throws CustomerException {

		Customer cust = customer.get(userName);
		return cust;
	}

}
