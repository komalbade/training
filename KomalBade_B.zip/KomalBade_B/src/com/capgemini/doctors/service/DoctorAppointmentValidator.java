package com.capgemini.doctors.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DoctorAppointmentValidator {

	public boolean validatepatientEmail(String email) {
		
		if(email==null)
			throw new NullPointerException();
		Pattern pat=Pattern.compile("^[A-za-z]{3,15}$@gmail.com");
		Matcher mat= pat.matcher(email);
		if(mat.matches())
			return true;
		else
			return false;
		
	}
	public boolean validateName(String name) {
		
		Pattern pat= Pattern.compile("^[A-Z][a-z]{4,15}$");
		Matcher mat= pat.matcher(name);
		if(mat.matches())
			return true;
		else
			return false;
	}
}
