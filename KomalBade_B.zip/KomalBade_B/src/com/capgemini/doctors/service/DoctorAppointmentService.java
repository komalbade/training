package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao dao;
	public DoctorAppointmentService()
	{
		dao=new DoctorAppointmentDao();
	}
	@Override
	public  DoctorAppointment addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorAppointmentException  {
		// TODO Auto-generated method stub
		doctorAppointment=dao.addDoctorAppointmentDetails(doctorAppointment);
		return doctorAppointment ;
	}
	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId)throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		return null;
	}
}
