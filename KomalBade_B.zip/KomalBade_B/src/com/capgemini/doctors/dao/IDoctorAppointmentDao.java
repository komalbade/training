package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public interface IDoctorAppointmentDao {

	public DoctorAppointment addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorAppointmentException;
	DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorAppointmentException;
}
