package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;


public class DoctorAppointmentDao implements IDoctorAppointmentDao{
	
	Map<Integer,DoctorAppointment>appointments=new HashMap<>();;

	@Override
	public  DoctorAppointment addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorAppointmentException{
		appointments.put(doctorAppointment.getAge(),doctorAppointment);
		return doctorAppointment ;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorAppointmentException {
		// TODO Auto-generated method stub
		DoctorAppointment doctor=new DoctorAppointment (); 
		return doctor;
	}

}
