package com.capgemini.doctors.test;

public class DoctorAppointmentTest {

}
