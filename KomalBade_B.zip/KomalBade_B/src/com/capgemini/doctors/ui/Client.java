package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.DoctorAppointmentValidator;
import com.capgemini.doctors.service.IDoctorAppointmentService;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int option;
		String email = null;
		DoctorAppointmentValidator validator=new DoctorAppointmentValidator();
		IDoctorAppointmentService service=new DoctorAppointmentService();
		do
		{
		DoctorAppointment doctor=new DoctorAppointment();
		
		System.out.println("1. Add patient ");
        System.out.println("4.Print patient List");
		System.out.println("5.Exit");
		System.out.println("Enter Option :->  ");
		option=sc.nextInt();
		option=sc.nextInt();
		
		switch(option) {
		case 1 :
			try {
		
		if(validator.validatepatientEmail(email)==false)
			throw new DoctorAppointmentException("Invalid Email " );
		System.out.println("Enter name of the patient:   ");
	    String name=sc.next();
			
		if(validator.validateName(name)==false)
			throw new DoctorAppointmentException("Invalid Name Format");
		System.out.println("Enter phone Number:  ");
		String mobno =sc.next();
		
		System.out.println("Ente Email:   ");
		String emID =sc.next();
		
		System.out.println("Enter Age:   ");
		int age=sc.nextInt();
		
		System.out.println("Enter Gender:   ");
		String gender=sc.next();
		
		System.out.println("Enter Problem Name:   ");
		String pbn=sc.next();
		doctor.setDoctorName(name);
		doctor.setPhoneNumber(mobno);
		doctor.setEmail(emID);
		doctor.setAge(age);
		doctor.setGender(gender);
		doctor.setProblemName(pbn);
		
			}catch(Exception e) {
			System.out.println(e.getMessage());
			break;
	    }
		case 2:
		System.exit(0);
	}
	}while(option!=1);	
}
}