public class Mobile
{

private String company;

/*public Mobile()
{
company="nokia";
}*/

public void setcompany(String company)
{
 this.company=company;
}

public String getcompany()
{
 return this.company;
}

/*public String toString()
{
 return "Hello Mobile...";
}*/




public static void main(String args[])
{
 Mobile obj1=new Mobile();
 Mobile obj2=new Mobile();
 obj1.setcompany("samsung");
 obj2.setcompany("oppo");
 System.out.println("\nThis is " + obj1.getcompany() + " mobile ");
 System.out.println("\nThis is " + obj2.getcompany() + " mobile ");
}
}
