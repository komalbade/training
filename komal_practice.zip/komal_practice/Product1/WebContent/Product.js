/**
 * 
 */
var category = new Array("Grocery","Electronics");
//var product = new Array();
//product[0]= new Array("Television","Laptop","Phone");
//product[1]= new Array("Soap","Powder");
//

function populateCategory()
{
	
	var categoryObj=window.document.formRegister.list;
	for(var i=0;i<category.length;i++)
	{
		categoryObj.options[i]=new Option(category[i],category[i]);
	}
	populateProduct();
}

function populateProduct()
{
	var product = new Array();
	//var arr;
	product[0]= new Array("Soap","Powder","trt");
	product[1]= new Array("Television","Laptop","Mobile","fdf","grgt");
	var categoryDataObj = window.document.formRegister.list;
	var productDataObj = window.document.formRegister.list1;
	var indexOfCategorySelected = categoryDataObj.selectedIndex;
	var category = document.getElementById("id1").value;
	if(category =="Electronics"){
		for(var j=0;j<product[1].length;j++)//[] take no of bigger array
		{
			
			productDataObj.options[j]=new Option(product[indexOfCategorySelected][j],product[indexOfCategorySelected][j]);
		
		
		}
	}else{
		for(var j=0;j<product[0].length;j++)//[] take no of bigger array
		{
			
			productDataObj.options[j]=new Option(product[indexOfCategorySelected][j],product[indexOfCategorySelected][j]);
		
		}
	}
}
	function add()
	{
	 var priceArrayE  =["20000","30000","10000"];
	 var priceArrayG = ["40","90",];
	 var total;
	 
	 var q=document.getElementById('c').value;
	 var s=document.getElementById('b');
	 
	 if(s.value == "Television")
	 {
		 total=priceArrayE[0]*q;
		 document.getElementById('d').value=total;
	 }
	 else if(s.value =="Laptop")
	 {
		 total=priceArrayE[1]*q;
		 document.getElementById('d').value=total; 
	 }
	 else if(s.value =="Mobile")
	 {
		 total=priceArrayE[2]*q;
		 document.getElementById('d').value=total; 
	 }
	
	 else if(s.value =="Soap")
	 {
		 total=priceArrayG[0]*q;
		 document.getElementById('d').value=total; 
	 }
	 else if(s.value =="Powder")
	 {
		 total=priceArrayG[1]*q;
		 document.getElementById('d').value=total; 
	 }

	}

