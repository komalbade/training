package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDemo {

	public static void main(String[] args) {
		
	 String query="update emp_insurance set insurance_scheme=? where empid=?";
	 Connection con=DatabaseConnection.getConnection();
	 Scanner sc=new Scanner(System.in);
	 try {
		 PreparedStatement ps= con.prepareCall(query);
		 System.out.println("Enter empid ");
		 int id=sc.nextInt();
		 System.out.println("Enter insurance scheme: ");
		 String scheme=sc.next();
		 
		 ps.setString(1, scheme);
		 ps.setInt(2, id);
		 
		 int count=ps.executeUpdate();
		 if(count==0)
			 	System.out.println("Employee Record not found");
		 else
			 System.out.println("Rows upadated : "+ count);
	 }catch(SQLException e) {
		 e.printStackTrace();
	 }
	 

	}

}
