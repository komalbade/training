package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertDemo {
public static void main(String[] args) {
		
	String query="insert into Emp_insurance values(?,?,?,?,?)";
	Scanner sc=new Scanner(System.in);
	Connection con=DatabaseConnection.getConnection();
     try {
		PreparedStatement ps=con.prepareStatement(query);
		System.out.println("Enter Empid");
		int id=sc.nextInt();
		System.out.println("Enter Name");
		String name=sc.next();
		System.out.println("Enter Salary");
		double salary=sc.nextDouble();
		System.out.println("Enter designation");
		String ds=sc.next();
		System.out.println("Enter Insurance Scheme");
		String sh=sc.next();
		
	
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setDouble(3, salary);
		ps.setString(4, ds);
		ps.setString(5,sh);
		
		int count=ps.executeUpdate();
		System.out.println("rows inserted : "+ count);
		
	}catch(SQLException e)
	{   
		e.printStackTrace();
	    if(e.getErrorCode()==900)
	    	System.out.println("insert query syntax is wrong...");
	    else if(e.getErrorCode()==91)
	    {
	       System.out.println("Employee id is already existing... please try new value");
	    }
		
	}
	
}
}
