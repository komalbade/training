package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class DeleteDemo {

	public static void main(String[] args) {
		String query="delete from emp_insurance where empid=?";
		Scanner sc=new Scanner(System.in);
		Connection con=DatabaseConnection.getConnection();
	    try {
	    	PreparedStatement ps=con.prepareStatement(query);
	    	System.out.println("Enter Employee ID ");
	    	int id=sc.nextInt();
	    	ps.setInt(1, id);
	    	int count =ps.executeUpdate();
	    	System.out.println("rows Deleted :"+ count);
	    }catch(SQLException e) {
	    	e.printStackTrace();
	    }
		

	}

}
