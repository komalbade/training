package com.cg.takehome.test;



import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import com.cg.takehome.service.ProductValidator;


public class ProductTest {
	ProductValidator validate = new ProductValidator();
	@Test
	public void testmethod1() {
		String productcode ="1001";
		boolean actual = validate.validateproductcode(productcode);
		boolean expected = true;
		assertEquals(expected,actual);
		
	}
	@Test
	public void testmethod2() {
		int quantity =-1;
		boolean actual = validate.validatequantity(quantity);
		boolean expected = false;
		assertEquals(expected,actual);
		
	}

}
