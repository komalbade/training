package com.cg.takehome.ui;

import java.util.Scanner;

import com.cg.takehome.bean.Product;
import com.cg.takehome.exception.ProductException;
import com.cg.takehome.service.ProductServiceImpl;
import com.cg.takehome.service.ProductValidator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	ProductServiceImpl productservice = new ProductServiceImpl();
	ProductValidator validate = new ProductValidator();
    Product products = new Product();
    System.out.println("Enter your option");
	System.out.println("1.Generate Bill \n2.Exit ");
	int option = sc.nextInt();

	switch(option) {
	case 1:
		try {
		System.out.println("enter product code");
		String productcode = sc.next();
		if(validate.validateproductcode(productcode)==false)
			throw new ProductException("Enter valid product code");
				
		System.out.println("Enter quantity");
		int quantity=sc.nextInt();
		if(validate.validatequantity(quantity)==false)
					throw new ProductException("Enter valid quantity");
			
		
	
			products=productservice.getProduct(Integer.parseInt(productcode));
			System.out.println("product name"+products.getProductname());
			System.out.println("product category"+products.getCategory());
//			System.out.println("product description"+products.getDescription());
			System.out.println("product price"+products.getPrice());
//			System.out.println("product quantity"+products.getQuantity());
			int total = quantity* products.getPrice();
			System.out.println("product total"+total);
System.out.println(""+products.getProductCode()+" "+products.getProductname());
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		break;
	case 2:
		System.exit(0);
		
	}
	
	}
}
