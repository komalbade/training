package com.cg.takehome.bean;

public class Product {
	private String productname;
	private int productCode;
	private String category;
	private String description;
	private int price;
	private int quantity;
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Product [productname=" + productname + ", productCode=" + productCode + ", category=" + category
				+ ", description=" + description + ", price=" + price + ", quantity=" + quantity + "]";
	}
	public Product(String productname, int productCode, String category,  int price) {
		super();
		this.productname = productname;
		this.productCode = productCode;
		this.category = category;
		
		this.price = price;
		
	}
public Product() {
	
}
}
