package com.cg.takehome.service;

import java.util.regex.Pattern;

import com.cg.takehome.exception.ProductException;

public class ProductValidator {
	public boolean validateproductcode(String id) {
		if(id==null)
			throw new NullPointerException();
			boolean flag = Pattern.matches("[1001-1004]{4}$", id);
			if (flag) {
				return true;
			}else
				return false;
	}
	public boolean validatequantity(int quantity) {
	
		if(quantity<=0)
			return false;
		else
			return true;
	}
}
