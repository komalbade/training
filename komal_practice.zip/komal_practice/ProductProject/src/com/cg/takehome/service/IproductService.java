package com.cg.takehome.service;

import com.cg.takehome.bean.Product;
import com.cg.takehome.exception.ProductException;

public interface IproductService {
	public Product getProduct(int id ) throws ProductException;

}
