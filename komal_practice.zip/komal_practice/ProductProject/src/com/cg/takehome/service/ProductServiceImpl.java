package com.cg.takehome.service;


import com.cg.takehome.bean.Product;
import com.cg.takehome.dao.IproductDAO;
import com.cg.takehome.dao.ProductDAOImpl;
import com.cg.takehome.exception.ProductException;

public class ProductServiceImpl implements IproductService{
	IproductDAO dao;

	public ProductServiceImpl() {
		dao = new ProductDAOImpl();
	}
	@Override
	public Product getProduct(int id) throws ProductException {
		return dao.getProduct(id);
		
	}

}
