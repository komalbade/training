package com.cg.takehome.dao;

import com.cg.takehome.bean.Product;
import com.cg.takehome.exception.ProductException;

public interface IproductDAO {
	public Product getProduct(int id ) throws ProductException;
	
}
