package com.cg.pack;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Path javaHome = Paths.get("C:/Program Files/Java/jdk1.8.0_25/hggh");
		  System.out.println(javaHome.get);}
	}


