public class SwitchCase
{

public static boolean CheckChar(char ch)
{
 switch(ch)
{
 case 'A':
 case 'a':
 case 'E':
 case 'e':
 case 'I':
 case 'i':
 case 'O':
 case 'o':
 case 'U':
 case 'u': return true;
 default: return false;
}

}

public static void main(String args[])
{
 char mychar='A';
if(CheckChar(mychar)==true)
{
 System.out.print("character"+mychar+ "is vowel");
}
else
{
System.out.print("character"+mychar+ "is not vowel");
}
}
}




