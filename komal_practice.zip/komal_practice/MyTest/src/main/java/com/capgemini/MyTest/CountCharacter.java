package com.capgemini.MyTest;



public class CountCharacter {

	public static int[] countcharacter(char ch[]) {

		int count1[] = new int[ch.length];
		for (char cha = 'a'; cha <= 'z'; cha++) {
			int count=0;
			
			for (int i = 0; i < ch.length; i++) {
				if (cha == ch[i]) {
					count++;
					//continue;
				}
				count1[i]=count;
			}
			
		}
		
		return count1;
	}

	

}

