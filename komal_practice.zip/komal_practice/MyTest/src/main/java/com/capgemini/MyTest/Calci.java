package com.capgemini.MyTest;


public class Calci {

	public static int main(int[] arr) {
		int max=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(max<arr[i])
				max=arr[i];
		}
return max;
	}	

}
