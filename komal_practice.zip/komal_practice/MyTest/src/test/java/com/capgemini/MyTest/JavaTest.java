package com.capgemini.MyTest;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

	public class JavaTest
	{
		@Test
		public void testfindMax()
		{
			int o[]={1,1,2,2,1,2};
			assertArrayEquals(o,CountCharacter.countcharacter(new char[]{'r','o','h','i','n','i'}));
			
			
		}
	}
		


