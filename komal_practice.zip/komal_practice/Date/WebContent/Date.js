/**
 * 
 */
function Validate()
{
	
	var qualArr1 = new Array("BCA","BSC","BBA","BE");
	var qual1 = window.document.formregister.education;
	
	for(var i=1;i<qualArr1.length;i++)
		{
			qual1.options[i] = new Option(qualArr1[i],qualArr1[i])
		}
		

}

function Validate1()
{
	var qualArr1 = new Array("MCA","MSC","MBA","ME");
	var qual1 = window.document.formregister.education;
	
	for(var i=1;i<qualArr1.length;i++)
		{
			qual1.options[i] = new Option(qualArr1[i],qualArr1[i])
		}
		

}
 function display()
 {
	var nameData = window.document.formregister.txt.value;
	var birthData = window.document.formregister.txtDate.value;
	var phoneData = window.document.formregister.telNo.value;
	var emailData = window.document.formregister.email.value;
	var radioData = window.document.formregister.ug.value;
	var qualData = window.document.formregister.education.value;
 
 
	var cgWinObj=window.open("","CGWindow","height = 800,width = 800")
	 cgWinObj.document.write("<body>");
     cgWinObj.document.write("PREVIEW");
     cgWinObj.document.write("<br>Name: "+nameData+"<br>");
     cgWinObj.document.write("<br>Date of Birth: "+birthData+"<br>");
     cgWinObj.document.write("<br>Phone Number:"+phoneData+"<br>");
     cgWinObj.document.write("<br>Email:"+emailData+"<br>");
     cgWinObj.document.write("<br>Graduation Level:"+radioData+"<br>");
     cgWinObj.document.write("<br>Qualification:"+qualData+"<br>");
     cgWinObj.document.write("</body>");
 }
