package Mypackage;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;


public class Customer {
	public String mobileNo(String s) {
		try
		{
			if(Pattern.matches("^[820][0-9]{9}", s)) 
				System.out.println("Mobile number correct");
			else
				throw new MobileException(s);
		}
		catch(MobileException e) {
			//System.out.println("mobile number should be 10 digit...");
			System.out.println("mobile number is incorrect..."+e);
		}
		return s;}
		@Test
		public void toCheck() {
			//Customer c=new Customer();
			String s1 = "8833082556";
			 assertEquals("8833082556", s1); 
			System.out.println("gfg");
		}
		
		
		
	
	public static void main(String args[]) {
		Customer c=new Customer();
		
		String s = c.mobileNo("8833082556");
		c.toCheck();
}
		
	}


