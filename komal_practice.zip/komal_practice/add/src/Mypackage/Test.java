package Mypackage;

public class Test {

	public static void main(String args[]) {
	
			int[] a = new int[0];
            System.out.print(a.length);
			}
	}


