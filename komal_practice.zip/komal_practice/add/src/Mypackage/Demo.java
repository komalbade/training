package Mypackage;

public class Demo 
{
   public static void main(String[] args) 
	{
		
	   String str = "null";
	   try
	   {
		 System.out.println(str.equals("happy"));
	   }
	   catch(NullPointerException e)
	   {
		    str=new String("hello");
		    System.out.println(str.equals("Hello"));
	   }
	   System.out.println("Continuing in the program");
	 
	}

}
