package Mypackage;

public class shape 
{
	
	
}
