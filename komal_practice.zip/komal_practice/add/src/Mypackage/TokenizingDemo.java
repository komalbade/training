package Mypackage;

public class TokenizingDemo {
 public static void main(String args[]) {
	 String str="hello I want to creat string tokens:   ";
	 String arr[]=str.split(" ");
	 for(String token:arr) {
		 System.out.println(token);
	 }
 }
}
