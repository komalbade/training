package Mypackage;

import java.util.HashSet;

public class HashSetDemo {
	public static void main(String args[])
	{
		HashSet<Integer>hm=new HashSet<Integer>();
		hm.add(100);
		hm.add(2);
		hm.add(300);
		hm.add(41);
		System.out.println(hm);
		
	}

}
