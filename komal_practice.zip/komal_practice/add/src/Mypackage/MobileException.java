package Mypackage;

public class MobileException extends Exception {
	MobileException(String s){
		super(s);
	}
	

}
