package Mypackage;

import java.util.regex.Pattern;

public class RegExpTest {
	public static void main(String args[]) {
		String s="komal";
		String s2="komal";
		boolean patternMatched=Pattern.matches(s2,s);
		System.out.print("pattern matched");
	}
	
	

}
