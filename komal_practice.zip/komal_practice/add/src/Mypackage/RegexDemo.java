package Mypackage;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo 
{

	public static void main(String[] args) 
	{
		Pattern p= Pattern.compile("\\.");
		String s[]=p.split("www.durgasoft.com");
		 for(String s1:s)
		{
			System.out.println(s1);
		}
				
}

}
