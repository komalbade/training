package Mypackage;

import java.util.Currency;
import java.util.Locale;

public class CurrencyDemo {
	public static void main(String args[]) {
		Locale lacale=Locale.getDefault();
		int amount=1000;
		Currency c=Currency.getInstance(lacale);
		System.out.println("using currency code :      "+amount+""+c.getCurrencyCode());
		System.out.println("using currency symbol :      "+amount+""+c.getSymbol());
		System.out.println("using currency code :      "+amount+""+c.getDisplayName());
	}

}
