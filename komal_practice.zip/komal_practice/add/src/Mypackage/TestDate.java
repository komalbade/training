package Mypackage;

import java.util.Date;

public class TestDate {

	public static void main(String[] args) {
		Date date1=new Date();
		Date date4 = new Date(0);
		Date date2=new Date(111111L);
		//Date date3=new Date(99L);
		System.out.println("Our first date is:   "+date1);
		System.out.println("Our second date is:   "+date4);
		
		System.out.println("Our second date is:   "+date2);
		//System.out.println("Our second date is:   "+date3);
		
		
		/*System.out.println("Our third date is:   "+date3);
		if(date1.after(date2)) {
			System.out.println("Our first date is after our second date:   ");
		}
		if(date2.before(date3)) {
			System.out.println("our second date is before our third date");
		}*/
		
	}

}
