package Mypackage;

public class DemoAbstract 
{
	public static void main(String[] args)
	{
		IMyInterface s=new Circle(5.4f);
		double result=s.calculateArea();
		System.out.println("Area of ahape circle is: "+ result);
	
	}
}
