package Mypackage;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<String,Double>hm=new HashMap<String,Double>();
		hm.put("komal",new Double("23.45"));
		hm.put("rohini",new Double("33.45"));
		hm.put("rutuja",new Double("43.45"));
		hm.put("onkar",new Double("53.45"));
		
		Set set=hm.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext())
		{
			HashMap.Entry me=(HashMap.Entry)i.next();
			System.out.println(me.getKey()+"  "+me.getValue());
		}
		
		
	}

}
