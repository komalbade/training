package Mypackage;

public class Circle extends shape implements IMyInterface 
{
   private float radius;
   public Circle(float radius) 
   {
	  this.radius=radius;
   }
   public void setRadius(float radius)
   {
	   this.radius=radius;
   }
   public float getRadius()
   {
	   return radius;
   }
   public double calculateArea()
   {
	   return (PI*this.getRadius()*this.getRadius());
   }
}
