package Mypackage;

public interface IMyInterface 
{
	double calculateArea();
	float PI=3.14f;
}
