import java.util.Collections;
public class ReverseArray
{
 public static void reverseArray(int arr[],int start,int end)
{

  int temp;
  while(start<end)
{
   temp=arr[start];
   arr[start]=arr[end];
   arr[end]=temp;
   start++;
   end--;
}
}
static void printArray(int arr[],int size)
{ 
  for(int i=0;i<size;i++)

   System.out.print(arr[i]+ " ");
   System.out.println();
}

 public static void main(String args[])
{

  int arr[]={1,2,3,7,4,9};
  Collections.sort(arr);
  System.out.println(arr);
  Collections.reverse(arr);
System.out.println(arr);
 

   }


}