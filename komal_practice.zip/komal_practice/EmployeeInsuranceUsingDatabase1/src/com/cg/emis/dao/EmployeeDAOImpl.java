package com.cg.emis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import com.cg.dbconnection.DatabaseConnection;
import com.cg.emis.bean.Employee;
import com.cg.emis.exception.EmployeeException;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	Connection con;
	public EmployeeDAOImpl()
	{
		con=DatabaseConnection.getConnection();
	}
	@Override
	public Employee AddEmployee(Employee emp) throws EmployeeException {
		String query="insert into Emp_insurance values(?,?,?,?,?)";
		try {
		PreparedStatement ps=con.prepareStatement(query);
		ps.setInt(1, emp.getEmpid());
		ps.setString(2,emp.getName());
		ps.setDouble(3,emp.getSalary());
		ps.setString(4, emp.getDesignation());
		ps.setString(5,emp.getInsuranceScheme());
		
		int count=ps.executeUpdate();
		
		}catch(SQLException e)
		{   
			e.printStackTrace();
		    if(e.getErrorCode()==900)
		    	System.out.println("insert query syntax is wrong...");
		    else if(e.getErrorCode()==91)
		    {
		       System.out.println("Employee id is already existing... please try new value");
		    }
		}
		return emp;
	}
	
	@Override
	public ArrayList<Employee> getEmployeeList() throws EmployeeException {
		String sql="select empid,name,salary ,designation,insurance_scheme"
				+ " from Emp_Insurance ";
	
		ArrayList<Employee> list= new ArrayList<>();
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
		
			while(rs.next()) {
				int id= rs.getInt(1);
				String name= rs.getString(2);
				double sal= rs.getDouble(3);
				String ds= rs.getString(4);
				String scheme= rs.getString(5);
				Employee emp= new Employee();
				emp.setEmpid(id);
				emp.setName(name);
				emp.setInsuranceScheme(scheme);
				emp.setSalary(sal);
				emp.setDesignation(ds);
				list.add(emp);
			}
			
		}catch(SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		
		return list;
	}

	@Override
	public Employee updateInsueranceScheme(int id) throws EmployeeException {
		
		Employee emp= new Employee();
		String query="select empid,salary,designation,insurance_scheme from emp_insurance where empid=? ";
		try {
			PreparedStatement ps= con.prepareStatement(query,
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			ps.setInt(1, id);
			ResultSet rs= ps.executeQuery();
			
			if(rs.next()) {
				String des= rs.getString("designation");
				double salary= rs.getDouble("salary");
				emp.setEmpid(rs.getInt(1));
				emp.setSalary(salary);
				emp.setDesignation(des);
				
				if(salary > 5000 && salary<=20000 && des.equals("System Associate"))
					emp.setInsuranceScheme("C");
				else if (salary>=20000 && salary<=40000 && des.equals("Programmer"))
					emp.setInsuranceScheme("B");
				else if (salary>40000 && des.equals("Manager"))
					emp.setInsuranceScheme("A");
				else if( salary <5000 && des.equals("Clerk"))
						emp.setInsuranceScheme("NA");
				else 
					emp.setInsuranceScheme("NA");
		
				rs.updateString("insurance_scheme",emp.getInsuranceScheme());
				rs.updateRow();
				}
			}catch(SQLException e) {
				e.printStackTrace();
		}
		return emp;
	}

	@Override
	public Employee deleteEmployee(int empid) throws EmployeeException {
		Employee emp=new Employee();
		String query="select empid,name,salary,designation,insurance_scheme from emp_insurance where empid=?";
		try {
	    	PreparedStatement ps=con.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
	    	ps.setInt(1, empid);
	    	
	    	ResultSet rs=ps.executeQuery();
	    	if(rs.next())
	    	{
	    		emp.setEmpid(rs.getInt(1));
	    		emp.setName(rs.getString(2));
	    		emp.setSalary(rs.getDouble(3));
	    		rs.deleteRow();
	    	}
	    	
	    	
	    }catch(SQLException e) {
	    	throw new EmployeeException(e.getMessage());
	    }
		return emp;
		
	}

	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
