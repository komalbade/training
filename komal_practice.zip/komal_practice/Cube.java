public class Cube
{
 int num=405,sum=0,rem,cube;
public void out()
{
 
    while(num>0)
{  
  
   rem=num%10;
   //cube=rem*rem*rem;
   sum=sum+(rem*rem*rem);
    num=num/10;
}
  
  System.out.print("sum of cubes of digits=  "+ sum);
}

public static void main(String []args)
{
   Cube c=new Cube();
   c.out();

}
}