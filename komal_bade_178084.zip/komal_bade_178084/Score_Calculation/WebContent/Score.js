/**
 * 
 */
var domainArra=new Array("JEE",".NET");
var moduleArr=new Array();
moduleArr[0]=new Array("Core Java","Servlet-JSP","Spring");
moduleArr[1]=new Array("C#","ADO.NET","ASP.NEt");

function populateDomain()
{
	var domainObj=window.document.formregister.domain;
	for(var i=0;i<domainArra.length;i++)
	{	
		domainObj.options[i]=new Option(domainArra[i],domainArra[i]);
	}
}

function populateModule()
{
var domainDataObj=window.document.formregister.domain;
var moduleDataObj=window.document.formregister.module;
var indexOfDomainSelected=domainDataObj.selectedIndex;

for(var j=0;j<moduleArr.length;j++){
    moduleDataObj.options[j]=new Option(moduleArr[indexOfDomainSelected][j],
	moduleArr[indexOfDomainSelected][j]);
}
}


var a=eval(window.document.getElementById("id1").value);
var b=eval(window.document.getElementById("id2").value);
var c=eval(window.document.getElementById("id3").value);
var avg = eval(a+b+c)/3;
function display()
{
	
	alert("Your Average score is"+avg);
	
}