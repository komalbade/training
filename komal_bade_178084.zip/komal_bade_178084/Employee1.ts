class Employee
{
	empId:number;
	empName:string;
	empSalary:Number;
	empDesignation:string;
}

let e1=new Employee();
e1.empId=1002;
e1.empName="Vikash";
e1.empSalary=9812;
e1.empDesignation=Consultant;

console.log("ID:"+e1.empId+"Name: "+e1.empName+"SALARY: "+e1.empSalary+Employee.Designation);